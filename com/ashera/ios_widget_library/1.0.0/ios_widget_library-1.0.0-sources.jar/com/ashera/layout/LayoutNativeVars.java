//start - license
/*
 * Copyright (c) 2025 Ashera Cordova
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
//end - license
package com.ashera.layout;

public class LayoutNativeVars {
	public static int NSLineBreakByMarquee;
	public static int UIFontDescriptorTraitItalic;
	public static int UIFontDescriptorTraitBold;
	public static int NSLineBreakByTruncatingTail;
	public static int NSLineBreakByTruncatingMiddle;
	public static int NSLineBreakByClipping;
	public static int NSLineBreakByTruncatingHead;
	public static int NSTextAlignmentJustified;
	public static int NSTextAlignmentLeft;
	public static int kCGBlendModeNotSupported = -1;
	public static int kCGBlendModeMultiply;
	public static int kCGBlendModeSourceAtop;
	public static int kCGBlendModeSourceIn;
	public static int kCGBlendModeNormal;
	public static int kCGBlendModeOverlay;
	public static int kCGBlendModeScreen;
	public static int UIDataDetectorTypeLink;
	public static int UIDataDetectorTypeAll;
	public static int UIDataDetectorTypeAddress;
	public static int UIDataDetectorTypeNone;
	public static int UIDataDetectorTypePhoneNumber;
	public static int UIViewContentModeCenter;
	public static int UIViewContentModeScaleAspectFill;
	public static int UIViewContentModeScaleAspectFit;
	public static int UIViewContentModeScaleToFill;
	public static int UIAccessibilityTraitAdjustable;
	public static int UIAccessibilityTraitAllowsDirectInteraction;
	public static int UIAccessibilityTraitButton;
	public static int UIAccessibilityTraitCausesPageTurn;
	public static int UIAccessibilityTraitHeader;
	public static int UIAccessibilityTraitImage;
	public static int UIAccessibilityTraitKeyboardKey;
	public static int UIAccessibilityTraitLink;
	public static int UIAccessibilityTraitNone;
	public static int UIAccessibilityTraitNotEnabled;
	public static int UIAccessibilityTraitPlaysSound;
	public static int UIAccessibilityTraitSearchField;
	public static int UIAccessibilityTraitSelected;
	public static int UIAccessibilityTraitStartsMediaSession;
	public static int UIAccessibilityTraitStaticText;
	public static int UIAccessibilityTraitSummaryElement;
	public static int UIAccessibilityTraitTabBar;
	public static int UIAccessibilityTraitUpdatesFrequently;
	public static int UITextAutocapitalizationTypeNone;
	public static int UITextAutocapitalizationTypeWords;
	public static int UITextAutocapitalizationTypeSentences;
	public static int UITextAutocapitalizationTypeAllCharacters;
	public static int UITextAutocorrectionTypeYes;
	public static int UITextAutocorrectionTypeNo;
	public static int UIKeyboardTypeDate;
	public static int UIKeyboardTypeDatetime;
	public static int UIKeyboardTypeNone;
	public static int UIKeyboardTypeNumber;
	public static int UIKeyboardTypeNumberDecimal;
	public static int UIKeyboardTypeNumberPassword;
	public static int UIKeyboardTypeNumberSigned;
	public static int UIKeyboardTypePhone;
	public static int UIKeyboardTypeText;
	public static int UIKeyboardTypeTextAutoComplete;
	public static int UIKeyboardTypeTextAutoCorrect;
	public static int UIKeyboardTypeTextCapCharacters;
	public static int UIKeyboardTypeTextCapSentences;
	public static int UIKeyboardTypeTextCapWords;
	public static int UIKeyboardTypeTextEmailAddress;
	public static int UIKeyboardTypeTextEmailSubject;
	public static int UIKeyboardTypeTextFilter;
	public static int UIKeyboardTypeTextImeMultiLine;
	public static int UIKeyboardTypeTextLongMessage;
	public static int UIKeyboardTypeTextMultiLine;
	public static int UIKeyboardTypeTextNoSuggestions;
	public static int UIKeyboardTypeTextPassword;
	public static int UIKeyboardTypeTextPersonName;
	public static int UIKeyboardTypeTextPhonetic;
	public static int UIKeyboardTypeTextPostalAddress;
	public static int UIKeyboardTypeTextShortMessage;
	public static int UIKeyboardTypeTextUri;
	public static int UIKeyboardTypeTextVisiblePassword;
	public static int UIKeyboardTypeTextWebEditText;
	public static int UIKeyboardTypeTextWebEmailAddress;
	public static int UIKeyboardTypeTextWebPassword;
	public static int UIKeyboardTypeTime;
	
	public static int UIReturnKeyTypeActionDone;
	public static int UIReturnKeyTypeActionGo;
	public static int UIReturnKeyTypeActionNext;
	public static int UIReturnKeyTypeActionNone;
	public static int UIReturnKeyTypeActionPrevious;
	public static int UIReturnKeyTypeActionSearch;
	public static int UIReturnKeyTypeActionSend;
	public static int UIReturnKeyTypeActionUnspecified;
	public static int UIReturnKeyTypeFlagForceAscii;
	public static int UIReturnKeyTypeFlagNavigateNext;
	public static int UIReturnKeyTypeFlagNavigatePrevious;
	public static int UIReturnKeyTypeFlagNoAccessoryAction;
	public static int UIReturnKeyTypeFlagNoEnterAction;
	public static int UIReturnKeyTypeFlagNoExtractUi;
	public static int UIReturnKeyTypeFlagNoFullscreen;
	public static int UIReturnKeyTypeFlagNoPersonalizedLearning;
	public static int UIReturnKeyTypeNormal;
	public static int UITextBorderStyleNone;
	public static int UITextBorderStyleLine;
	public static int UITextBorderStyleBezel;
	public static int UITextBorderStyleRoundedRect;
	
	public static int UITableViewCellSeparatorStyleSingleLine;
	public static int UITableViewCellSeparatorStyleNone;
	
	public static int UITableViewCellSelectionStyleNone;
	public static int UITableViewCellSelectionStyleGray;
	public static int UITableViewCellSelectionStyleBlue;
	public static int UITableViewCellSelectionStyleDefault;

	static {
		nativeSetVars();
	}
    private native static void nativeSetVars() /*-[	    
		ASLayoutNativeVars_UIFontDescriptorTraitItalic =  (jint) UIFontDescriptorTraitItalic;
		ASLayoutNativeVars_UIFontDescriptorTraitBold =  (jint) UIFontDescriptorTraitBold;
		ASLayoutNativeVars_NSLineBreakByTruncatingTail =  (jint) NSLineBreakByTruncatingTail;
		ASLayoutNativeVars_NSLineBreakByTruncatingMiddle =  (jint) NSLineBreakByTruncatingMiddle;
		ASLayoutNativeVars_NSLineBreakByClipping =  (jint) NSLineBreakByClipping;
		ASLayoutNativeVars_NSLineBreakByMarquee =  -2;
		ASLayoutNativeVars_NSLineBreakByTruncatingHead =  (jint) NSLineBreakByTruncatingHead;
		ASLayoutNativeVars_NSTextAlignmentJustified =  (jint) NSTextAlignmentJustified;
		ASLayoutNativeVars_NSTextAlignmentLeft =  (jint) NSTextAlignmentLeft;
		
		ASLayoutNativeVars_kCGBlendModeMultiply =  (jint) kCGBlendModeMultiply;
		ASLayoutNativeVars_kCGBlendModeSourceAtop =  (jint) kCGBlendModeSourceAtop;
		ASLayoutNativeVars_kCGBlendModeSourceIn =  (jint) kCGBlendModeSourceIn;
		ASLayoutNativeVars_kCGBlendModeNormal =  (jint) kCGBlendModeNormal;
		ASLayoutNativeVars_kCGBlendModeOverlay =  (jint) kCGBlendModeOverlay;
		ASLayoutNativeVars_kCGBlendModeScreen =  (jint) kCGBlendModeScreen;
		
		ASLayoutNativeVars_UIDataDetectorTypeLink =  (jint) UIDataDetectorTypeLink;
		ASLayoutNativeVars_UIDataDetectorTypeAll =  (jint) UIDataDetectorTypeAll;
		ASLayoutNativeVars_UIDataDetectorTypeAddress =  (jint) UIDataDetectorTypeAddress;
		ASLayoutNativeVars_UIDataDetectorTypeNone =  (jint) UIDataDetectorTypeNone;
		ASLayoutNativeVars_UIDataDetectorTypePhoneNumber =  (jint) UIDataDetectorTypePhoneNumber;
		
		ASLayoutNativeVars_UIViewContentModeScaleAspectFill =  (jint) UIViewContentModeScaleAspectFill;
		ASLayoutNativeVars_UIViewContentModeCenter =  (jint) UIViewContentModeCenter;
		ASLayoutNativeVars_UIViewContentModeScaleAspectFit =  (jint) UIViewContentModeScaleAspectFit;
		ASLayoutNativeVars_UIViewContentModeScaleToFill =  (jint) UIViewContentModeScaleToFill;
		
		ASLayoutNativeVars_UIAccessibilityTraitAdjustable = (jint) UIAccessibilityTraitAdjustable;
		ASLayoutNativeVars_UIAccessibilityTraitAllowsDirectInteraction = (jint) UIAccessibilityTraitAllowsDirectInteraction;
		ASLayoutNativeVars_UIAccessibilityTraitButton = (jint) UIAccessibilityTraitButton; 
		ASLayoutNativeVars_UIAccessibilityTraitCausesPageTurn = (jint) UIAccessibilityTraitCausesPageTurn; 
		ASLayoutNativeVars_UIAccessibilityTraitHeader = (jint) UIAccessibilityTraitHeader;
		ASLayoutNativeVars_UIAccessibilityTraitImage = (jint) UIAccessibilityTraitImage; 
		ASLayoutNativeVars_UIAccessibilityTraitKeyboardKey = (jint) UIAccessibilityTraitKeyboardKey; 
		ASLayoutNativeVars_UIAccessibilityTraitLink = (jint) UIAccessibilityTraitLink; 
		ASLayoutNativeVars_UIAccessibilityTraitNone = (jint) UIAccessibilityTraitNone; 
		ASLayoutNativeVars_UIAccessibilityTraitNotEnabled = (jint) UIAccessibilityTraitNotEnabled; 
		ASLayoutNativeVars_UIAccessibilityTraitPlaysSound = (jint) UIAccessibilityTraitPlaysSound; 
		ASLayoutNativeVars_UIAccessibilityTraitSearchField = (jint) UIAccessibilityTraitSearchField; 
		ASLayoutNativeVars_UIAccessibilityTraitSelected =  (jint) UIAccessibilityTraitSelected; 
		ASLayoutNativeVars_UIAccessibilityTraitStartsMediaSession = (jint) UIAccessibilityTraitStartsMediaSession; 
		ASLayoutNativeVars_UIAccessibilityTraitStaticText = (jint) UIAccessibilityTraitStaticText; 
		ASLayoutNativeVars_UIAccessibilityTraitSummaryElement = (jint) UIAccessibilityTraitSummaryElement; 
		ASLayoutNativeVars_UIAccessibilityTraitTabBar = (jint) UIAccessibilityTraitTabBar; 
		ASLayoutNativeVars_UIAccessibilityTraitUpdatesFrequently = (jint) UIAccessibilityTraitUpdatesFrequently;
		
		ASLayoutNativeVars_UITextAutocapitalizationTypeNone = (jint) UITextAutocapitalizationTypeNone; 
		ASLayoutNativeVars_UITextAutocapitalizationTypeWords = (jint) UITextAutocapitalizationTypeWords; 
		ASLayoutNativeVars_UITextAutocapitalizationTypeSentences = (jint) UITextAutocapitalizationTypeSentences; 
		ASLayoutNativeVars_UITextAutocapitalizationTypeAllCharacters = (jint) UITextAutocapitalizationTypeAllCharacters;
		 
		ASLayoutNativeVars_UITextAutocorrectionTypeYes = (jint) UITextAutocorrectionTypeYes; 
		ASLayoutNativeVars_UITextAutocorrectionTypeNo = (jint) UITextAutocorrectionTypeNo; 
		
		ASLayoutNativeVars_UIKeyboardTypeDate = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeDatetime = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeNone = (jint)  UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeNumber = (jint) UIKeyboardTypeNumberPad;
		ASLayoutNativeVars_UIKeyboardTypeNumberDecimal = (jint) UIKeyboardTypeDecimalPad;
		ASLayoutNativeVars_UIKeyboardTypeNumberPassword = (jint) UIKeyboardTypeNumberPad;
		ASLayoutNativeVars_UIKeyboardTypeNumberSigned = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypePhone = (jint) UIKeyboardTypePhonePad;
		ASLayoutNativeVars_UIKeyboardTypeText = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextAutoComplete = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextAutoCorrect = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextCapCharacters = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextCapSentences = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextCapWords = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextEmailAddress = (jint) UIKeyboardTypeEmailAddress;
		ASLayoutNativeVars_UIKeyboardTypeTextEmailSubject = (jint) UIKeyboardTypeEmailAddress;
		ASLayoutNativeVars_UIKeyboardTypeTextFilter = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextImeMultiLine = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextLongMessage = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextMultiLine = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextNoSuggestions = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextPassword = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextPersonName = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextPhonetic = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextPostalAddress = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextShortMessage = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextUri = (jint) UIKeyboardTypeURL;
		ASLayoutNativeVars_UIKeyboardTypeTextVisiblePassword = (jint) UIKeyboardTypeDefault;
		ASLayoutNativeVars_UIKeyboardTypeTextWebEditText = (jint) UIKeyboardTypeWebSearch;
		ASLayoutNativeVars_UIKeyboardTypeTextWebEmailAddress = (jint) UIKeyboardTypeEmailAddress;
		ASLayoutNativeVars_UIKeyboardTypeTextWebPassword = (jint) UIKeyboardTypeWebSearch;
		ASLayoutNativeVars_UIKeyboardTypeTime = (jint) UIKeyboardTypeDefault;
		
		ASLayoutNativeVars_UIReturnKeyTypeActionDone = (jint) UIReturnKeyDone;
		ASLayoutNativeVars_UIReturnKeyTypeActionGo = (jint) UIReturnKeyGo;
		ASLayoutNativeVars_UIReturnKeyTypeActionNext = (jint) UIReturnKeyNext;
		ASLayoutNativeVars_UIReturnKeyTypeActionNone = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeActionPrevious = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeActionSearch = (jint) UIReturnKeySearch;
		ASLayoutNativeVars_UIReturnKeyTypeActionSend = (jint) UIReturnKeySend;
		ASLayoutNativeVars_UIReturnKeyTypeActionUnspecified = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeFlagForceAscii = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeFlagNavigateNext = (jint) UIReturnKeyNext;
		ASLayoutNativeVars_UIReturnKeyTypeFlagNavigatePrevious = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeFlagNoAccessoryAction = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeFlagNoEnterAction = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeFlagNoExtractUi = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeFlagNoFullscreen = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeFlagNoPersonalizedLearning = (jint) UIReturnKeyDefault;
		ASLayoutNativeVars_UIReturnKeyTypeNormal = (jint) UIReturnKeyDefault;
		
		ASLayoutNativeVars_UITextBorderStyleNone = (jint) UITextBorderStyleNone;
		ASLayoutNativeVars_UITextBorderStyleLine = (jint) UITextBorderStyleLine;
		ASLayoutNativeVars_UITextBorderStyleBezel = (jint) UITextBorderStyleBezel;
		ASLayoutNativeVars_UITextBorderStyleRoundedRect = (jint) UITextBorderStyleRoundedRect;

		ASLayoutNativeVars_UITableViewCellSeparatorStyleSingleLine = (jint) UITableViewCellSeparatorStyleSingleLine;
		ASLayoutNativeVars_UITableViewCellSeparatorStyleNone = (jint) UITableViewCellSeparatorStyleNone;
		
		ASLayoutNativeVars_UITableViewCellSelectionStyleGray = (jint) UITableViewCellSelectionStyleGray;
		ASLayoutNativeVars_UITableViewCellSelectionStyleNone = (jint) UITableViewCellSelectionStyleNone;
		ASLayoutNativeVars_UITableViewCellSelectionStyleBlue = (jint) UITableViewCellSelectionStyleBlue;
		ASLayoutNativeVars_UITableViewCellSelectionStyleDefault = (jint) UITableViewCellSelectionStyleDefault;
	]-*/;
}
